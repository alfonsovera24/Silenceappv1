package com.silencio.auriculares;

import android.Manifest;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int COLOR_BG = 0xFF0E0E10;
    private static final int COLOR_ACCENT = 0xFF3DDC97;
    private static final int COLOR_OFF = 0xFF8A8A92;

    private PowerView button;
    private TextView label;
    private TextView modeLabel;
    private static final String[] MODE_NAMES = {"silencio", "ultrasonido", "ruido mínimo"};
    private boolean on = false;
    private long lastTap = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(COLOR_BG);

        button = new PowerView(this);
        button.setContentDescription("Activar o desactivar");
        button.setOnClickListener(v -> toggle());
        root.addView(button, new LinearLayout.LayoutParams(dp(220), dp(220)));

        label = new TextView(this);
        label.setTextSize(15);
        label.setLetterSpacing(0.35f);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(28);
        root.addView(label, lp);

        modeLabel = new TextView(this);
        modeLabel.setTextSize(12);
        modeLabel.setTextColor(0xFF5A5A62);
        modeLabel.setPadding(dp(24), dp(16), dp(24), dp(16));
        modeLabel.setOnClickListener(v -> cycleMode());
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp2.topMargin = dp(40);
        root.addView(modeLabel, lp2);
        showMode(prefs().getInt(SilenceService.KEY_MODE, 0));

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        SilenceService.listener = () -> render(SilenceService.running, true);
        render(SilenceService.running, false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        SilenceService.listener = null;
    }

    private void toggle() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastTap < 700) return; // evita toques dobles
        lastTap = now;

        Intent svc = new Intent(this, SilenceService.class);
        if (on) {
            stopService(svc);
            render(false, true);
        } else {
            startForegroundService(svc);
            render(true, true);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(SilenceService.PREFS, MODE_PRIVATE);
    }

    private void showMode(int m) {
        modeLabel.setText("MODO " + (m + 1) + " · " + MODE_NAMES[m] + "  (toca para cambiar)");
    }

    private void cycleMode() {
        int m = (prefs().getInt(SilenceService.KEY_MODE, 0) + 1) % SilenceService.MODES;
        prefs().edit().putInt(SilenceService.KEY_MODE, m).apply();
        showMode(m);
        if (on) startForegroundService(new Intent(this, SilenceService.class)); // reinicia con el modo nuevo
    }

    private void render(boolean state, boolean animate) {
        on = state;
        button.setOn(on, animate);
        label.setText(on ? "ON" : "OFF");
        label.setTextColor(on ? COLOR_ACCENT : COLOR_OFF);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** Boton circular minimalista con icono de encendido. */
    static class PowerView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ArgbEvaluator eval = new ArgbEvaluator();
        private final float density;
        private float t = 0f; // 0 = apagado, 1 = encendido
        private ValueAnimator anim;

        PowerView(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
            fill.setStyle(Paint.Style.FILL);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(COLOR_ACCENT);
            ring.setStyle(Paint.Style.STROKE);
            icon.setStyle(Paint.Style.STROKE);
            icon.setStrokeCap(Paint.Cap.ROUND);
        }

        void setOn(boolean on, boolean animate) {
            float target = on ? 1f : 0f;
            if (anim != null) anim.cancel();
            if (!animate) {
                t = target;
                invalidate();
                return;
            }
            anim = ValueAnimator.ofFloat(t, target);
            anim.setDuration(250);
            anim.addUpdateListener(a -> {
                t = (float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        private int blend(int from, int to) {
            return (Integer) eval.evaluate(t, from, to);
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) / 2f - 16 * density;

            glow.setAlpha((int) (45 * t));
            c.drawCircle(cx, cy, r + 10 * density, glow);

            fill.setColor(blend(0xFF18181B, COLOR_ACCENT));
            c.drawCircle(cx, cy, r, fill);

            ring.setStrokeWidth(2 * density);
            ring.setColor(blend(0xFF3A3A40, COLOR_ACCENT));
            c.drawCircle(cx, cy, r, ring);

            float ir = r * 0.36f;
            icon.setStrokeWidth(r * 0.1f);
            icon.setColor(blend(COLOR_OFF, COLOR_BG));
            c.drawArc(new RectF(cx - ir, cy - ir, cx + ir, cy + ir), -60, 300, false, icon);
            c.drawLine(cx, cy - ir * 1.15f, cx, cy - ir * 0.1f, icon);
        }
    }
}
