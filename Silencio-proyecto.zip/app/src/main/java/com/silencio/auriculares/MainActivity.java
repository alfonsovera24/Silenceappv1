package com.silencio.auriculares;

import android.Manifest;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int COLOR_BG = 0xFF0E0E10;
    private static final int COLOR_ACCENT = 0xFF3DDC97;
    private static final int COLOR_OFF = 0xFF8A8A92;
    private static final int COLOR_DIM = 0xFF6A6A72;

    private PowerView button;
    private TextView label, freqText, levelText, micText;
    private SeekBar freqBar, levelBar;
    private boolean on = false;
    private long lastTap = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sp = prefs();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        int size = Math.min(dp(200), (int) (getResources().getDisplayMetrics().heightPixels * 0.36f));
        button = new PowerView(this);
        button.setContentDescription("Activar o desactivar");
        button.setOnClickListener(v -> toggle());
        root.addView(button, new LinearLayout.LayoutParams(size, size));

        label = text(15, 0.35f);
        root.addView(label, top(12));

        int barW = Math.min(dp(300), getResources().getDisplayMetrics().widthPixels - dp(48));
        SeekBar.OnSeekBarChangeListener changed = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                updateTexts();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                saveAndApply();
            }
        };

        freqText = text(12, 0.15f);
        freqText.setTextColor(COLOR_DIM);
        root.addView(freqText, top(28));
        freqBar = bar(SilenceService.FREQ_STEPS, sp.getInt(SilenceService.KEY_FREQ, SilenceService.DEF_FREQ), changed);
        root.addView(freqBar, new LinearLayout.LayoutParams(barW, LinearLayout.LayoutParams.WRAP_CONTENT));

        levelText = text(12, 0.15f);
        levelText.setTextColor(COLOR_DIM);
        root.addView(levelText, top(12));
        levelBar = bar(SilenceService.LEVEL_MAX, sp.getInt(SilenceService.KEY_LEVEL, SilenceService.DEF_LEVEL), changed);
        root.addView(levelBar, new LinearLayout.LayoutParams(barW, LinearLayout.LayoutParams.WRAP_CONTENT));

        micText = text(12, 0.15f);
        micText.setPadding(dp(24), dp(16), dp(24), dp(16));
        micText.setOnClickListener(v -> toggleMic());
        root.addView(micText, top(16));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(COLOR_BG);
        scroll.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        updateTexts();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        SilenceService.listener = () -> render(SilenceService.running, true);
        render(SilenceService.running, false);
        updateMic();
    }

    @Override
    protected void onStop() {
        super.onStop();
        SilenceService.listener = null;
    }

    // ---------- encendido ----------

    private void toggle() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastTap < 700) return; // evita toques dobles
        lastTap = now;

        Intent svc = new Intent(this, SilenceService.class);
        if (on) {
            stopService(svc);
            render(false, true);
        } else {
            startForegroundService(svc);
            render(true, true);
        }
    }

    private void render(boolean state, boolean animate) {
        on = state;
        button.setOn(on, animate);
        label.setText(on ? "ON" : "OFF");
        label.setTextColor(on ? COLOR_ACCENT : COLOR_OFF);
    }

    // ---------- perillas ----------

    private void updateTexts() {
        double khz = (SilenceService.FREQ_MIN + freqBar.getProgress() * SilenceService.FREQ_STEP) / 1000.0;
        freqText.setText(String.format(Locale.US, "FRECUENCIA  %.1f kHz", khz));
        int lv = levelBar.getProgress();
        levelText.setText(lv == 0 ? "NIVEL  silencio"
                : "NIVEL  " + (SilenceService.LEVEL_DB_BASE + lv) + " dB");
    }

    private void saveAndApply() {
        prefs().edit()
                .putInt(SilenceService.KEY_FREQ, freqBar.getProgress())
                .putInt(SilenceService.KEY_LEVEL, levelBar.getProgress())
                .apply();
        if (on) startForegroundService(new Intent(this, SilenceService.class)); // reinicia con valores nuevos
    }

    // ---------- microfono ----------

    private void toggleMic() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            boolean before = am.isMicrophoneMute();
            am.setMicrophoneMute(!before);
            if (am.isMicrophoneMute() == before) {
                Toast.makeText(this, "Android no permite cortar el micrófono desde una app. "
                        + "Usa «Acceso al micrófono» en el panel rápido.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo cambiar el micrófono.", Toast.LENGTH_SHORT).show();
        }
        updateMic();
    }

    private void updateMic() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        boolean muted = am.isMicrophoneMute();
        micText.setText(muted ? "MIC · CORTADO" : "MIC · ACTIVO");
        micText.setTextColor(muted ? COLOR_ACCENT : COLOR_DIM);
    }

    // ---------- helpers de UI ----------

    private SharedPreferences prefs() {
        return getSharedPreferences(SilenceService.PREFS, MODE_PRIVATE);
    }

    private TextView text(int sizeSp, float spacing) {
        TextView t = new TextView(this);
        t.setTextSize(sizeSp);
        t.setLetterSpacing(spacing);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private LinearLayout.LayoutParams top(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        return lp;
    }

    private SeekBar bar(int max, int progress, SeekBar.OnSeekBarChangeListener l) {
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(progress);
        s.setProgressTintList(ColorStateList.valueOf(COLOR_ACCENT));
        s.setThumbTintList(ColorStateList.valueOf(COLOR_ACCENT));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF3A3A40));
        s.setOnSeekBarChangeListener(l);
        return s;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** Boton circular minimalista con icono de encendido. */
    static class PowerView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ArgbEvaluator eval = new ArgbEvaluator();
        private final float density;
        private float t = 0f; // 0 = apagado, 1 = encendido
        private ValueAnimator anim;

        PowerView(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
            fill.setStyle(Paint.Style.FILL);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(COLOR_ACCENT);
            ring.setStyle(Paint.Style.STROKE);
            icon.setStyle(Paint.Style.STROKE);
            icon.setStrokeCap(Paint.Cap.ROUND);
        }

        void setOn(boolean on, boolean animate) {
            float target = on ? 1f : 0f;
            if (anim != null) anim.cancel();
            if (!animate) {
                t = target;
                invalidate();
                return;
            }
            anim = ValueAnimator.ofFloat(t, target);
            anim.setDuration(250);
            anim.addUpdateListener(a -> {
                t = (float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        private int blend(int from, int to) {
            return (Integer) eval.evaluate(t, from, to);
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) / 2f - 16 * density;

            glow.setAlpha((int) (45 * t));
            c.drawCircle(cx, cy, r + 10 * density, glow);

            fill.setColor(blend(0xFF18181B, COLOR_ACCENT));
            c.drawCircle(cx, cy, r, fill);

            ring.setStrokeWidth(2 * density);
            ring.setColor(blend(0xFF3A3A40, COLOR_ACCENT));
            c.drawCircle(cx, cy, r, ring);

            float ir = r * 0.36f;
            icon.setStrokeWidth(r * 0.1f);
            icon.setColor(blend(COLOR_OFF, COLOR_BG));
            c.drawArc(new RectF(cx - ir, cy - ir, cx + ir, cy + ir), -60, 300, false, icon);
            c.drawLine(cx, cy - ir * 1.15f, cx, cy - ir * 0.1f, icon);
        }
    }
}
