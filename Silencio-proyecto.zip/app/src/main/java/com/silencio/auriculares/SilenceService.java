package com.silencio.auriculares;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.IBinder;

/**
 * Mantiene una salida de audio activa en bucle, sin pedir foco de audio
 * (se mezcla con cualquier otra app sin pausarla ni bajarle el volumen).
 *
 * Reproduce un tono de frecuencia y nivel ajustables (por defecto 20 kHz a -60 dB).
 * Nivel 0 = silencio digital puro.
 */
public class SilenceService extends Service {

    public static final String ACTION_STOP = "com.silencio.auriculares.STOP";
    public static final String PREFS = "silencio";
    public static final String KEY_FREQ = "freq";   // 0..FREQ_STEPS
    public static final String KEY_LEVEL = "level"; // 0..LEVEL_MAX

    public static final int FREQ_MIN = 12000;  // Hz
    public static final int FREQ_STEP = 100;   // Hz por paso
    public static final int FREQ_STEPS = 100;  // 12 kHz .. 22 kHz
    public static final int DEF_FREQ = 80;     // 20 kHz
    public static final int LEVEL_MAX = 60;
    public static final int LEVEL_DB_BASE = -90; // nivel n => (-90 + n) dBFS; 0 = silencio
    public static final int DEF_LEVEL = 30;      // -60 dBFS

    public static volatile boolean running = false;
    public static Runnable listener; // la Activity se entera de los cambios

    private static final String CHANNEL_ID = "silencio";
    private static final int NOTIF_ID = 1;
    private static final int SAMPLE_RATE = 48000;

    private AudioTrack track;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        createChannel();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }

        // Si ya sonaba (p.ej. al mover una perilla), se reinicia con los valores nuevos.
        releaseTrack();
        if (!startTrack(true) && !startTrack(false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        notifyListener();
        return START_NOT_STICKY;
    }

    /** useFloat: audio de 32 bits (sin redondeo a 16 bits); si falla, se prueba con 16 bits. */
    private boolean startTrack(boolean useFloat) {
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            int level = sp.getInt(KEY_LEVEL, DEF_LEVEL);
            int hz = FREQ_MIN + sp.getInt(KEY_FREQ, DEF_FREQ) * FREQ_STEP;
            double amp = level <= 0 ? 0 : Math.pow(10, (LEVEL_DB_BASE + level) / 20.0);

            int frames = SAMPLE_RATE; // 1 s en bucle; Hz enteros => ciclos exactos, sin clics
            int sampleCount = frames * 2;

            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(useFloat ? AudioFormat.ENCODING_PCM_FLOAT
                            : AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build();

            // MODE_STATIC + bucle infinito: lo reproduce el sistema, sin hilos
            // ni wake locks (casi no gasta bateria).
            int bytes = sampleCount * (useFloat ? 4 : 2);
            track = new AudioTrack(attrs, format, bytes,
                    AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE);
            // En modo STATIC el estado es NO_STATIC_DATA hasta cargar los datos.
            if (track.getState() == AudioTrack.STATE_UNINITIALIZED) {
                releaseTrack();
                return false;
            }

            int written;
            if (useFloat) {
                float[] d = new float[sampleCount];
                if (amp > 0) {
                    for (int n = 0; n < frames; n++) {
                        float s = (float) (amp * Math.sin(2 * Math.PI * hz * (double) n / SAMPLE_RATE));
                        d[2 * n] = s;
                        d[2 * n + 1] = s;
                    }
                }
                written = track.write(d, 0, d.length, AudioTrack.WRITE_BLOCKING);
            } else {
                short[] d = new short[sampleCount];
                if (amp > 0) {
                    for (int n = 0; n < frames; n++) {
                        short s = (short) Math.round(
                                amp * 32767 * Math.sin(2 * Math.PI * hz * (double) n / SAMPLE_RATE));
                        d[2 * n] = s;
                        d[2 * n + 1] = s;
                    }
                }
                written = track.write(d, 0, d.length);
            }

            if (written <= 0 || track.getState() != AudioTrack.STATE_INITIALIZED) {
                releaseTrack();
                return false;
            }
            track.setLoopPoints(0, frames, -1);
            track.play();
            return true;
        } catch (Exception e) {
            releaseTrack();
            return false;
        }
    }

    private void releaseTrack() {
        if (track != null) {
            try {
                track.stop();
            } catch (Exception ignored) {
            }
            track.release();
            track = null;
        }
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Silencio", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, SilenceService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat), "Apagar", stop).build();

        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Silencio activo")
                .setContentText("Manteniendo los auriculares despiertos")
                .setContentIntent(open)
                .addAction(stopAction)
                .setOngoing(true);
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private static void notifyListener() {
        Runnable l = listener;
        if (l != null) l.run();
    }

    @Override
    public void onDestroy() {
        releaseTrack();
        running = false;
        notifyListener();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
