package com.silencio.auriculares;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.IBinder;

import java.util.Random;

/**
 * Reproduce en bucle un audio casi imperceptible (ruido de +-1 LSB, ~ -90 dBFS)
 * para que el sistema mantenga la salida de audio "activa" y los auriculares
 * no generen su ruido de reposo.
 *
 * NO pide foco de audio, asi que se mezcla con cualquier otra app sin pausarla
 * ni bajarle el volumen.
 */
public class SilenceService extends Service {

    public static final String ACTION_STOP = "com.silencio.auriculares.STOP";
    public static volatile boolean running = false;
    public static Runnable listener; // la Activity se entera de los cambios

    private static final String CHANNEL_ID = "silencio";
    private static final int NOTIF_ID = 1;
    private static final int SAMPLE_RATE = 48000;
    // Cuanto mayor, menos "senal". 1 de cada 32 muestras vale +-1.
    // Si tus auriculares igual silban, baja este numero (p.ej. 8).
    private static final int DENSITY = 32;

    private AudioTrack track;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        createChannel();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }

        if (track == null && !startTrack()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        notifyListener();
        return START_NOT_STICKY;
    }

    private boolean startTrack() {
        try {
            int frames = SAMPLE_RATE; // 1 segundo en bucle
            short[] data = new short[frames * 2];
            Random r = new Random();
            for (int i = 0; i < data.length; i++) {
                if (r.nextInt(DENSITY) == 0) {
                    data[i] = (short) (r.nextBoolean() ? 1 : -1);
                }
            }

            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build();

            // MODE_STATIC + bucle infinito: lo reproduce el sistema, sin hilos
            // ni wake locks (casi no gasta bateria).
            track = new AudioTrack(attrs, format, data.length * 2,
                    AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE);
            // En modo STATIC el estado es NO_STATIC_DATA hasta cargar los datos.
            if (track.getState() == AudioTrack.STATE_UNINITIALIZED) {
                track.release();
                track = null;
                return false;
            }
            track.write(data, 0, data.length);
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                track.release();
                track = null;
                return false;
            }
            track.setLoopPoints(0, frames, -1);
            track.play();
            return true;
        } catch (Exception e) {
            if (track != null) {
                track.release();
                track = null;
            }
            return false;
        }
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Silencio", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, SilenceService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat), "Apagar", stop).build();

        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Silencio activo")
                .setContentText("Manteniendo los auriculares despiertos")
                .setContentIntent(open)
                .addAction(stopAction)
                .setOngoing(true);
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private static void notifyListener() {
        Runnable l = listener;
        if (l != null) l.run();
    }

    @Override
    public void onDestroy() {
        if (track != null) {
            try {
                track.stop();
            } catch (Exception ignored) {
            }
            track.release();
            track = null;
        }
        running = false;
        notifyListener();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
